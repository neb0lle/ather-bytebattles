# Template Application for ASDK-GEN2

This application is meant to be used as starting point for developing application firmware using ASDK-GEN2.

## Getting started

## How to build application firmware

The ASDK-GEN2 build system uses `CMake` to generate build recipes using `Ninja` instead of makefiles. It provides a python setup script (`asdk-gen2/setup/setup.py`) which downloads the required tools and sets up the necessary build environment giving user the same experience regardless of the host operating system.

#### System requirements

> Ensure that following requirements are satisifed before proceeding any further.

* Host OS:
    1. [x] Windows 11 - `10.0.22621 Build 22621` [tested]
    2. [x] Ubuntu - `20.04.5 LTS x86_64` [tested]
    3. [ ] Mac OS - (verified, gcc un-signed binary test pending)
* Supported Python versions:
    * [x] Python >= `v2.7.x` [tested]
    * [x] Python >= `v3.8.x` [tested]

#### Overview

The below steps briefs about the user's action to build application with ASDK-GEN2.

1. Install the toolchain for your target platform if you haven't installed yet.
2. Build application.

#### 1. Installing the toolchain

The setup script downloads all the necessary build tools and the required toolchain of the target platform.

* *Run the setup script to install and setup the complete build environment.*

    ```sh
    # once installed, you don't need to run it again
    python ./asdk-gen2/setup/setup.py
    ```

* *Output:*

    ```sh
    INFO: getting cmake...
    INFO: downloaded successfully
    INFO: extracting 'cmake-3.26.4-linux-x86_64' to '/home/jaimin/asdk_toolchain'...
    INFO: extracted successfully
    INFO: getting ninja...
    INFO: downloaded successfully
    INFO: extracting 'cmake-3.26.4-linux-x86_64.tar.gz' to '/home/jaimin/asdk_toolchain/ninja'...
    INFO: extracted successfully
    INFO: getting 'arm' toolchain (version: 'gcc-arm-none-eabi-7-2018-q2-update')...
    INFO: downloaded successfully
    INFO: extracting 'gcc-arm-none-eabi-7-2018-q2-update-linux.tar.bz2' to '/home/jaimin/asdk_toolchain/arm'...
    INFO: extracted successfully
    INFO: Setting envrionment variables...
    INFO: setting 'ASDK_TOOLCHAIN_ROOT' variable
    INFO: setting 'ASDK_ARM_TOOLCHAIN_VERSION' variable
    INFO: setting 'ASDK_ARM_TOOLCHAIN_ROOT' variable
    INFO: setting 'ASDK_NINJA_ROOT' variable
    INFO: setting 'ASDK_CMAKE_ROOT' variable
    INFO: Environment variables were added successfully.
    Note: Log-out then Log-in back to take effect & then start build.
    INFO: ASDK environment setup completed successfully!
    ```

Below we've listed the tools that gets downloaded under `<user's home>/asdk_toolchain` directory.
1. CMake - `v3.26.4`
2. Ninja - `v1.11.1`
3. ARM GCC toolchain - `gcc-arm-none-eabi-7-2018-q2-update`

#### 2. Build application

* *Run the build script*
    ```sh
    python build.py
    ```

* *Output:*
    ```sh
    -- The C compiler identification is GNU 7.3.1
    -- The CXX compiler identification is GNU 7.3.1
    -- Detecting C compiler ABI info
    -- Detecting C compiler ABI info - done
    -- Check for working C compiler: /home/jaimin/asdk_toolchain/arm/gcc-arm-none-eabi-7-2018-q2-update/bin/arm-none-eabi-gcc - skipped
    -- Detecting C compile features
    -- Detecting C compile features - done
    -- Detecting CXX compiler ABI info
    -- Detecting CXX compiler ABI info - done
    -- Check for working CXX compiler: /home/jaimin/asdk_toolchain/arm/gcc-arm-none-eabi-7-2018-q2-update/bin/arm-none-eabi-g++ - skipped
    -- Detecting CXX compile features
    -- Detecting CXX compile features - done
    CMake version:3.26.4

    Platform: CYT2B75

    -- The ASM compiler identification is GNU
    -- Found assembler: /home/jaimin/asdk_toolchain/arm/gcc-arm-none-eabi-7-2018-q2-update/bin/arm-none-eabi-gcc
    In Middleware
    -- Checking ASDK scheduler option
    -- Checking ASDK scheduler option - disabled
    -- Configuring done (0.2s)
    -- Generating done (0.0s)
    -- Build files have been written to: /home/jaimin/work/asdk2/asdk-gen2-sample-app/build
    [54/54] cd /home/jaimin/work/asdk2/asdk...asdk-gen2-sample-app/build/asdk_app.hex
    build completed succesfully!
    ```

Ensure that you are are able to build the project succesfully without any errors and warnings. If not then reach out to the ASDK team.

You are now ready to start writing a new application or port existing application to `ASDK-GEN2`. Refer the [how to add application source files](./docs/how_to_add_source_files.md) section for more information. It explains the folder structure and has user guide on how to write an application firmware in the `ASDK-GEN2` way.
