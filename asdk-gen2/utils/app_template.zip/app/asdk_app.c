/* ASDK User actions starts ************************************************ */

/* ASDK User Action: add application include files */
#include "app_gpio.h"
#include "dummy_gc.h"

/* below functions are called by main.c */

void asdk_app_init()
{
    /* ASDK User Action: add application init calls */
    app_gpio_init();
}

void asdk_app_loop()
{
    for (;;)
    {
        /* ASDK User Action: add application iteration calls */
        app_gpio_evt_handler();
        dummy_generated_code_fun();
    }
}

/* ASDK User actions ends ************************************************** */
