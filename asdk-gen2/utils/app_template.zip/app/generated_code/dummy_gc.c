#include "dummy_gc.h"

void dummy_generated_code_fun()
{
    __ASM("NOP");
}
