#ifndef DUMMY_GC_H
#define DUMMY_GC_H

/* Platform dependent includes */
#include "asdk_platform.h"

void dummy_generated_code_fun();

#endif
