#ifndef APP_GPIO_H
#define APP_GPIO_H

/* ASDK includes */
#include "asdk_gpio.h"
#include "asdk_mcu_pins.h"

/* Application specific: GPIO Events */
typedef enum
{
    INVALID_LED_EVT = 0,
    DISABLE_LED_EVT,
    ENABLE_LED_EVT,

    MAX_EVTS
} gpio_events_t;

/* Application specific APIs */
void app_gpio_init();
void app_gpio_evt_handler();

#endif
