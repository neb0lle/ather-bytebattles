#ifndef ASDK_APP_H
#define ASDK_APP_H

void asdk_app_init();
void asdk_app_loop();

#endif
