/* ASDK: do not edit main file ********************************************* */

/* Platform dependent includes */
#include "asdk_platform.h"

/* ASDK app includes */
#include "asdk_app.h"

int main()
{
    // todo: combine and change system_init()
    __enable_irq();
    SystemInit();

    // asdk application
    asdk_app_init();
    asdk_app_loop();

    return 0;
}

/* ASDK: do not edit main file ********************************************* */
