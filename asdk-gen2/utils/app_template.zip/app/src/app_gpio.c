/* Platform dependent includes */
#include "asdk_platform.h"

/* ASDK includes */
#include "asdk_error.h"

/* Application specific includes */
#include "app_gpio.h"

#define DELAY_100_MS 100000
#define DELAY_250_MS 250000
#define DELAY_500_MS 500000

#define LOOP_DELAY DELAY_250_MS

static asdk_gpio_config_t user_led_1 =
    {
        .mcu_pin = MCU_PIN_77,
        .gpio_mode = ASDK_GPIO_MODE_OUTPUT,
        .gpio_init_state = ASDK_GPIO_STATE_HIGH,
        .gpio_pull = ASDK_GPIO_PUSH_PULL};

static asdk_gpio_config_t user_led_4 =
    {
        .mcu_pin = MCU_PIN_47,
        .gpio_mode = ASDK_GPIO_MODE_OUTPUT,
        .gpio_init_state = ASDK_GPIO_STATE_HIGH,
        .gpio_pull = ASDK_GPIO_PUSH_PULL};

static asdk_gpio_config_t user_button =
    {
        .mcu_pin = MCU_PIN_29,
        .gpio_mode = ASDK_GPIO_MODE_INPUT,
        .gpio_pull = ASDK_GPIO_HIGH_Z,
        .gpio_interrupt_type = ASDK_GPIO_INTERRUPT_FALLING_EDGE};

static asdk_gpio_config_t other_button =
    {
        .mcu_pin = MCU_PIN_34,
        .gpio_mode = ASDK_GPIO_MODE_INPUT,
        .gpio_pull = ASDK_GPIO_PULL_DOWN,
        .gpio_interrupt_type = ASDK_GPIO_INTERRUPT_BOTH_EDGES};

static gpio_events_t gpio_evt = INVALID_LED_EVT;

static void gpio_callback(asdk_mcu_pin_t mcu_pin, uint32_t param)
{
    switch (mcu_pin)
    {
    case MCU_PIN_29:
        if (ASDK_GPIO_STATE_LOW == param)
        {
            gpio_evt = DISABLE_LED_EVT;
        }
        break;

    case MCU_PIN_34:
        gpio_evt = ENABLE_LED_EVT;
        /* rising edge */
        if (ASDK_GPIO_STATE_HIGH == param)
        {
        }
        /* falling edge */
        if (ASDK_GPIO_STATE_LOW == param)
        {
        }
        break;

    default:
        gpio_evt = INVALID_LED_EVT;
        break;
    }
}

void app_gpio_evt_handler()
{
    // process event
    switch (gpio_evt)
    {
    case ENABLE_LED_EVT:
        asdk_gpio_init(&user_led_4);
        gpio_evt = INVALID_LED_EVT;
        break;

    case DISABLE_LED_EVT:
        asdk_gpio_deinit(user_led_4.mcu_pin);
        gpio_evt = INVALID_LED_EVT;
        break;

    default:
        asdk_gpio_output_toggle(user_led_1.mcu_pin);
        asdk_gpio_output_toggle(user_led_4.mcu_pin);
        Cy_SysTick_DelayInUs(LOOP_DELAY);
        break;
    }
}

void app_gpio_init()
{
    asdk_errorcode_t status = ASDK_GPIO_SUCCESS;

    status = asdk_gpio_init(&user_led_1);
    ASDK_DEV_ERROR_ASSERT(status, ASDK_GPIO_SUCCESS);

    status = asdk_gpio_init(&user_led_4);
    ASDK_DEV_ERROR_ASSERT(status, ASDK_GPIO_SUCCESS);

    status = asdk_gpio_init(&user_button);
    ASDK_DEV_ERROR_ASSERT(status, ASDK_GPIO_SUCCESS);

    status = asdk_gpio_init(&other_button);
    ASDK_DEV_ERROR_ASSERT(status, ASDK_GPIO_SUCCESS);

    status = asdk_gpio_assign_callback(gpio_callback);
    ASDK_DEV_ERROR_ASSERT(status, ASDK_GPIO_SUCCESS);
}


