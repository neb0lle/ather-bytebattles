# How to add application source files

Before we get into it adding source files you must understand how the folder structure is organized. The below image represents the folder structure.

<img src="./images/asdk-app-structure.png" width="448"/>

    asdk-gen2/:
    - Is an ASDK git submodule that contains the necessary drivers, middleware and platform recipes to be built along with your application.

    build.py:
    - Is a python build script to build your application firmware.
    - Picks up the right toolchain and required tools based on the selected platform.

    CMakeLists.txt: 
    - It is a top-level CMake file.
    - Do not modify this file.
    - Instead use the 'app/config/app_config.cmake' for adding new source files.

## Application folder structure

The application folder (app) contains all of your application source files (*.h, *.c, *.ld & generated_code). The below image represents `./app` folder structure.

<img src="./images/asdk-app-folder.png" width="448"/>

Add all your source files within designated folders:
    
    app/inc/
    - Add your header (*.h) files.
    
    app/src/
    - Add your source (*.c) files.

    app/generated_code
    - Add all the source files (*.h, *.c) that are generated using other tools.

User configuration files:

    app/config/
    - All user configuration related files are placed here.

    app/config/app_config.cmake
    - Application configuration file.
    - Add application specific compile defintions, flags, source files, include paths...etc.
    
    app/config/asdk_config.cmake
    - ASDK configuration file.
    - Configure as per application requirements, you may include or exclude middleware components.
    - It is entirely optional, you may build application by disabling complete middleware.

Others:
    
    app/linker_files/
    - Maintain platform specifc linker files here - (WIP).
    - Only CYT2B75 is supported for now, for other platforms please consult with ASDK team.

## How to write application

Simply add your source files in the designated folders as explained earlier in the [application folder structure](#application-folder-structure) secion. Then in the `asdk_app.c` file start adding the init functions within `app_init()` function followed by the iteration functions within `app_loop()` function.

The below code-snippet should seed an idea.

```c
// asdk_app.c

#include "app_gpio.h"   // include header file from 'app/inc'
#include "dummy_gc.h"   // include header file from 'app/generate_code'

/* below functions are called by main.c */

void app_init()
{
    // initialize LED pins
    app_gpio_init();
}

void app_loop()
{
    for (;;)
    {
        // blink LEDs
        app_gpio_evt_handler();

        dummy_generated_code_fun();
    }
}
```

If you intend to create further folders within `app/` folder or any other places then you must explicitly inform cmake to pick it from `app/config/app_config.cmake` file.

Below is an snippet from the file that represents how `generated_code` folder is included. Similarly you should include other folders that you create.

```cmake
### add source files and include paths

# NOTE: you must add include paths under 'APP_USER_INC' variable
SET(APP_USER_INC 
    ${CMAKE_CURRENT_SOURCE_DIR}/app/generated_code

    # add other includes from here
    # example:
    # ${CMAKE_CURRENT_SOURCE_DIR}/app/app_imu
)

# NOTE: you must add source paths under 'APP_USER_SRC' variable
AUX_SOURCE_DIRECTORY(${CMAKE_CURRENT_SOURCE_DIR}/app/generated_code APP_USER_SRC)

# add other source paths from here
# example:
# AUX_SOURCE_DIRECTORY(${CMAKE_CURRENT_SOURCE_DIR}/app/app_imu APP_USER_SRC)
```

Explore the template application project to get hands-on experience with it.

